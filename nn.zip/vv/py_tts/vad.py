import asyncio
import websockets
import contextlib
import wave
import io
import webrtcvad
import whisper
import json
import base64
import pyttsx3
import tempfile
import os

import audioop
import requests

from gtts import gTTS
from pydub import AudioSegment
 
from TTS.api import TTS
import torch

import numpy as np
from scipy.io.wavfile import write as write_wav
import scipy.signal
 

# Configuration
MODEL = 'tinyllama'
LANGUAGE = 'english'
PORT = 8089
SAMPLE_RATE = 8000
FRAME_DURATION = 30  # ms
FRAME_SIZE = int(SAMPLE_RATE * FRAME_DURATION / 1000) * 2
SILENCE_LIMIT = 0.1  # seconds
SILENCE_FRAMES = int(SILENCE_LIMIT * 1000 / FRAME_DURATION)

vad = webrtcvad.Vad(2)
whisper_model = whisper.load_model("base")  # Load once

device = "cuda" if torch.cuda.is_available() else "cpu"
# tts = TTS(model_name="tts_models/en/ljspeech/fast_pitch").to(device)
from TTS.config.shared_configs import BaseDatasetConfig
from TTS.tts.configs.xtts_config import XttsConfig
from TTS.tts.models.xtts import XttsAudioConfig, XttsArgs

try:
    torch.serialization.add_safe_globals([
        BaseDatasetConfig,
        XttsConfig,
        XttsAudioConfig,
        XttsArgs
    ])
    print("Added Coqui TTS custom classes to PyTorch's safe globals for loading.")
except AttributeError:
    print("Warning: torch.serialization.add_safe_globals not available. "
          "You might be on an older PyTorch version.")
tts = TTS(model_name="tts_models/multilingual/multi-dataset/xtts_v2").to(device)
 
def write_wav1(audio_data):
    wav_buffer = io.BytesIO()
    with contextlib.closing(wave.open(wav_buffer, 'wb')) as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SAMPLE_RATE)
        wf.writeframes(audio_data)
    wav_buffer.seek(0)
    return wav_buffer

def transcribe_audio(wav_io):
    with open("temp.wav", "wb") as f:
        f.write(wav_io.read())
    result = whisper_model.transcribe("temp.wav", language=LANGUAGE)
    os.remove("temp.wav")
    text = result["text"].strip()
    print("📝  LLM thinks you said:", text)
    return text

import time;


async def speak_xtts_v2(text,websocket):
    text = text

    wav = tts.tts(
    text=text,
    speaker=None,
    speaker_wav="/vv/en-IN-Chirp-HD-O.wav",  # Default voice
    language="en"    # Language code
    )

    orig_sr = tts.synthesizer.output_sample_rate  # typically 22050 or 16000

    # Convert to NumPy array
    wav_np = np.array(wav, dtype=np.float32)

    # Resample to 8000 Hz
    target_sr = 8000
    wav_resampled = scipy.signal.resample_poly(wav_np, up=target_sr, down=orig_sr)

    # Normalize and convert to int16 (LINEAR16)
    wav_int16 = np.int16(wav_resampled / np.max(np.abs(wav_resampled)) * 32767)

    # Save to buffer as raw PCM (no WAV headers)
    buffer = io.BytesIO()
    buffer.write(wav_int16.tobytes())
    buffer.seek(0)

    # Encode to base64
    audio_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    smessage = {
    "type": "streamAudio",
    "data": {
    "audioDataType": "raw",
    "sampleRate": SAMPLE_RATE,
    "audioData": audio_base64
    }
    }

    # Send to client
    await  websocket.send(json.dumps(smessage))
   
 

async def speak(text,websocket):
    text = text

    wav = tts.tts(text)
    orig_sr = tts.synthesizer.output_sample_rate  # typically 22050 or 16000

    # Convert to NumPy array
    wav_np = np.array(wav, dtype=np.float32)

    # Resample to 8000 Hz
    target_sr = 8000
    wav_resampled = scipy.signal.resample_poly(wav_np, up=target_sr, down=orig_sr)

    # Normalize and convert to int16 (LINEAR16)
    wav_int16 = np.int16(wav_resampled / np.max(np.abs(wav_resampled)) * 32767)

    # Save to buffer as raw PCM (no WAV headers)
    buffer = io.BytesIO()
    buffer.write(wav_int16.tobytes())
    buffer.seek(0)

    # Encode to base64
    audio_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    smessage = {
    "type": "streamAudio",
    "data": {
    "audioDataType": "raw",
    "sampleRate": SAMPLE_RATE,
    "audioData": audio_base64
    }
    }

    # Send to client
    await  websocket.send(json.dumps(smessage))



async def stream_gtts_audio_as_pcm(text,websocket):
    tts = gTTS(text=text, lang='en')

    for chunk in tts.stream():
        # chunk is a bytes object of MP3 data chunk
        
        # Wrap chunk bytes into a BytesIO buffer
        mp3_buffer = io.BytesIO(chunk)

        # Load chunk as audio segment (pydub can read from BytesIO)
        audio_segment = AudioSegment.from_file(mp3_buffer, format="mp3")

        # Convert to mono and 8000 Hz sample rate
        audio_segment = audio_segment.set_frame_rate(8000).set_channels(1).set_sample_width(2)

        # Get raw PCM bytes (Linear16)
        pcm_data = audio_segment.raw_data
        
        # Now you can send pcm_data directly
        #yield pcm_data
        b64_audio = base64.b64encode(pcm_data).decode("utf-8")

        # Format message
        smessage = {
        "type": "streamAudio",
        "data": {
        "audioDataType": "raw",
        "sampleRate": SAMPLE_RATE,
        "audioData": b64_audio,
        }
        }

        # Send to client
        await  websocket.send(json.dumps(smessage))

def frame_generator(audio_bytes):
    for i in range(0, len(audio_bytes), FRAME_SIZE):
        yield audio_bytes[i:i + FRAME_SIZE]
def ask_ollama(prompt: str, model: str = "gemma3:4b") -> str:
    url = "http://127.0.0.1:11434/api/generate"
    headers = {"Content-Type": "application/json"}
    payload = {
        "model": model,
        "prompt": prompt+" answer in only 2 lines dont include emojis",
        "stream": False
    }

    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()  # raise error for HTTP failures
        data = response.json()
        print(data.get("response", "No response received."))
        return data.get("response", "No response received.")
    except requests.RequestException as e:
        print(f"❌ Ollama API error: {e}") 
        return "Sorry, something went wrong."

async def handle_websocket(websocket):
    print(f"🔌 WebSocket connected: {websocket.remote_address}")
    audio_buffer = bytearray()
    silence_frames = 0
    speech_frame_count = 0
    triggered = False

    try:
        async for message in websocket:
            if not isinstance(message, bytes):
                print("⚠️ Received non-bytes message, ignoring.")
                continue

            audio_buffer.extend(message)

            frames = list(frame_generator(audio_buffer))
            if not frames or len(frames[-1]) < FRAME_SIZE:
                continue

            is_speech = vad.is_speech(frames[-1], SAMPLE_RATE)

            if is_speech:
                silence_frames = 0
                speech_frame_count += 1
                triggered = True
            elif triggered:
                silence_frames += 1
                if silence_frames > SILENCE_FRAMES and speech_frame_count >= 5:
                    print("⏳ Silence detected, processing speech chunk...")
                    wav_io = write_wav1(audio_buffer)
                    question = transcribe_audio(wav_io)

                    if question:
                        # Convert text to speech
                        answer=  ask_ollama(question)
                        #tts_audio = await stream_gtts_audio_as_pcm(answer,websocket)
                        tts_audio = await speak_xtts_v2(answer,websocket)

                        # Encode to base64

                    # Reset
                    audio_buffer = bytearray()
                    silence_frames = 0
                    speech_frame_count = 0
                    triggered = False

    except websockets.ConnectionClosed:
        print("❌ WebSocket connection closed.")

async def start_server():
    print(f"🌐 WebSocket server listening on ws://0.0.0.0:{PORT}")
    async with websockets.serve(handle_websocket, "0.0.0.0", PORT):
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(start_server())
