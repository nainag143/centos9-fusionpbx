mv /etc/freeswitch /etc/freeswitch.orig
mkdir /etc/freeswitch
cp -R /var/www/fusionpbx/app/switch/resources/conf/* /etc/freeswitch
