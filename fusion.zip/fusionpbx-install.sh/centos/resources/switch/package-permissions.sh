#!/bin/sh

#default permissions
chown -R freeswitch:daemon /etc/freeswitch
chown -R freeswitch:daemon /var/lib/freeswitch
chown -R freeswitch:daemon /usr/share/freeswitch
chown -R freeswitch:daemon /var/log/freeswitch
chown -R freeswitch:daemon /var/run/freeswitch
